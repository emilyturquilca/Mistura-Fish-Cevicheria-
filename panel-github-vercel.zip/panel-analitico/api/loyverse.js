// Proxy seguro hacia la API de Loyverse: el token vive solo en el servidor.
const PERMITIDAS = ['/receipts', '/items', '/categories', '/customers'];
module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  const clave = process.env.APP_PASSWORD;
  if (!clave || req.headers['x-clave'] !== clave) return res.status(401).json({ error: 'No autorizado' });
  if (!process.env.LOYVERSE_TOKEN) return res.status(500).json({ error: 'Falta LOYVERSE_TOKEN' });
  const { path, ...resto } = req.query;
  if (!PERMITIDAS.includes(path)) return res.status(400).json({ error: 'Ruta no permitida' });
  const u = new URL('https://api.loyverse.com/v1.0' + path);
  Object.entries(resto).forEach(([k, v]) => v && u.searchParams.set(k, v));
  try {
    const r = await fetch(u, { headers: { Authorization: 'Bearer ' + process.env.LOYVERSE_TOKEN } });
    res.status(r.status).setHeader('Content-Type', 'application/json').send(await r.text());
  } catch (e) { res.status(502).json({ error: 'No se pudo contactar a Loyverse' }); }
};
